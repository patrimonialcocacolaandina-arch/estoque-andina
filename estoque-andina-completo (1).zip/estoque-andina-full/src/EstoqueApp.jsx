
// 🚀 Sistema Completo de Controle de Estoque com Login, Relatórios, Exportação, Dashboard e Integração
// 📌 Desenvolvido para atender gestores e colaboradores

import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectContent, SelectItem } from "@/components/ui/select";
import { motion } from "framer-motion";
import * as XLSX from "xlsx";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from "chart.js";
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

export default function EstoqueApp() {
  const [logged, setLogged] = useState(false);
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");

  const [itemName, setItemName] = useState("");
  const [quantidade, setQuantidade] = useState(1);
  const [estoque, setEstoque] = useState([]);
  const [log, setLog] = useState([]);

  const fazerLogin = () => {
    if (user === "gestor" && password === "123") {
      setRole("gestor");
      setLogged(true);
    } else if (user === "colaborador" && password === "123") {
      setRole("colaborador");
      setLogged(true);
    } else {
      alert("Login inválido!");
    }
  };

  const adicionarItem = () => {
    if (!itemName) return;
    const novoItem = { nome: itemName, qtd: quantidade };
    setEstoque([...estoque, novoItem]);
    setLog([...log, { acao: "Adicionado", item: itemName, qtd: quantidade, por: role, data: new Date() }]);
    setItemName("");
    setQuantidade(1);
  };

  const removerItem = (index) => {
    const removido = estoque[index];
    setLog([...log, { acao: "Removido", item: removido.nome, qtd: removido.qtd, por: role, data: new Date() }]);
    const novo = [...estoque];
    novo.splice(index, 1);
    setEstoque(novo);
  };

  const exportarExcel = () => {
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(log.map((l) => ({
      Ação: l.acao,
      Item: l.item,
      Quantidade: l.qtd,
      Usuário: l.por,
      Data: l.data.toLocaleString(),
    })));
    XLSX.utils.book_append_sheet(wb, ws, "Movimentações");
    XLSX.writeFile(wb, "Relatorio_Estoque.xlsx");
  };

  const chartData = {
    labels: log.map((l) => l.data.toLocaleTimeString()),
    datasets: [
      {
        label: "Movimentações",
        data: log.map((l) => (l.acao === "Adicionado" ? l.qtd : -l.qtd)),
        borderColor: "#2563eb",
        backgroundColor: "#60a5fa",
      },
    ],
  };

  const enviarParaSharePoint = async () => {
    alert("📡 Integração simulada! Aqui você pode configurar um POST para SharePoint ou Power Automate.");
  };

  if (!logged) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gray-100">
        <Card className="p-6 w-96">
          <CardContent className="flex flex-col gap-4">
            <h2 className="text-xl font-bold text-center mb-4">Login</h2>
            <Input placeholder="Usuário (gestor/colaborador)" value={user} onChange={(e) => setUser(e.target.value)} />
            <Input placeholder="Senha (123)" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <Button onClick={fazerLogin} className="bg-blue-600 text-white">Entrar</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6 flex flex-col gap-6">
      <motion.h1 initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-3xl font-bold text-center">
        Sistema Completo de Estoque
      </motion.h1>

      {role === "gestor" && (
        <Card className="p-4 max-w-xl mx-auto">
          <CardContent className="flex flex-col gap-4">
            <p className="font-semibold">Adicionar Item ao Estoque</p>
            <Input placeholder="Nome do item" value={itemName} onChange={(e) => setItemName(e.target.value)} />
            <Input type="number" min="1" value={quantidade} onChange={(e) => setQuantidade(Number(e.target.value))} />
            <Button onClick={adicionarItem} className="bg-green-600 text-white">Adicionar</Button>
          </CardContent>
        </Card>
      )}

      <Card className="p-4 max-w-xl mx-auto">
        <CardContent>
          <p className="font-semibold mb-4">Estoque Atual</p>
          <div className="flex flex-col gap-3">
            {estoque.length === 0 && <p className="text-gray-500">Nenhum item no estoque.</p>}
            {estoque.map((item, index) => (
              <Card key={index} className="p-3 flex justify-between items-center bg-white shadow-md rounded-xl">
                <span>{item.nome} — {item.qtd} unid.</span>
                {role === "colaborador" && (
                  <Button onClick={() => removerItem(index)} className="bg-red-600 text-white px-3 py-1 text-sm rounded-xl">
                    Remover
                  </Button>
                )}
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="p-4 max-w-xl mx-auto">
        <CardContent>
          <h2 className="text-lg font-bold mb-3">Relatório de Movimentações</h2>
          {log.map((l, i) => (
            <p key={i}>➡️ {l.acao} | {l.item} | {l.qtd} unid | {l.por} | {l.data.toLocaleString()}</p>
          ))}
          <Button onClick={exportarExcel} className="mt-4 bg-emerald-600 text-white">Exportar Excel</Button>
        </CardContent>
      </Card>

      <Card className="p-4 max-w-xl mx-auto">
        <CardContent>
          <h2 className="text-lg font-bold mb-4">Dashboard</h2>
          <Line data={chartData} />
        </CardContent>
      </Card>

      <Button onClick={enviarParaSharePoint} className="mx-auto mt-6 bg-purple-600 text-white">
        Enviar Movimentações ao SharePoint / Power Automate
      </Button>
    </div>
  );
}
