// Cole aqui o código completo do sistema.
// Arquivo gerado automaticamente.