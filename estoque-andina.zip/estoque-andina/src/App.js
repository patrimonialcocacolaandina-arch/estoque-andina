import EstoqueApp from "./EstoqueApp";
export default function App() {
  return <EstoqueApp />;
}