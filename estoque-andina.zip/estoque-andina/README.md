# Sistema de Estoque Andina
Sistema completo com:
- Login (gestor e colaborador)
- Controle de estoque
- Relatórios e histórico
- Exportação para Excel
- Dashboard com gráficos
- Multiempresa
- Integração com Power Automate

## Como rodar na Vercel
1. Envie os arquivos para um repositório no GitHub
2. Acesse https://vercel.com
3. Clique em New Project
4. Importe o repositório
5. Deploy!
